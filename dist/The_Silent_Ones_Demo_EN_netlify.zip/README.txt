THE SILENT ONES – DEMO
English. The first case of Chapter 1 (Split): Ivka, who waits on the pier
for the seven o'clock boat. The demo ends once Ivka has crossed over.

PLAYING
- Deploy the folder to Netlify (drag the unzipped folder onto
  app.netlify.com/drop) or open index.html via a web server.
- Tap something to look at it; if something can be done with it, a small
  menu appears. Drag items from the bar onto their target – also onto Mala.
- Bottom left switches between Marko and Mala (Tab or M).
- "Notes" (N), "Reveal" (Z). Esc opens the menu.
