THE SILENT ONES – DEMO
English. The first case of Chapter 1 (Split): Ivka, who waits on the pier
for the seven o'clock boat. The demo ends once Ivka has crossed over.

It starts with a short tutorial: Marko won't do anything before his coffee,
and making it teaches the controls step by step (look, take, use an item on
something, combine two items, Reveal, hints). A panel at the top of the
picture says what to do next and a frame marks the spot. Menu > Hint helps
at every step.

PLAYING
- Deploy the folder to Netlify (drag the unzipped folder onto
  app.netlify.com/drop) or open index.html via a web server.
- Tap something to look at it; if something can be done with it, a small
  menu appears. Drag items from the bar onto their target – also onto Mala.
- Bottom left switches between Marko and Mala (Tab or M).
- "Notes" (N), "Reveal" (Z). Esc opens the menu.
