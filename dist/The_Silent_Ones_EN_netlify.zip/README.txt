THE SILENT ONES – CHAPTER 1: SPLIT · CHAPTER 2: SARAJEVO · CHAPTER 3: MOSTAR
· CHAPTER 4: MUNICH · CHAPTER 5: SARAJEVO
English version (iPad and browser). English only.

WHAT IT IS ABOUT
Split, November 2011. Marko Vuković, a translator, can talk to people who
cannot move on. Mala, a ghost, can find them. Five chapters, from Split to
Sarajevo, Mostar, Munich and back to Sarajevo.

PLAYING
- Open index.html via a web server (or deploy the folder to Netlify:
  drag the unzipped folder onto app.netlify.com/drop).
- Tap something: if there is only something to see, Marko looks at it.
  If something can be done with it, a small menu appears.
- Drag items from the bar onto their target – also onto Mala.
- Bottom left switches between Marko and Mala (Tab or M).
- "Notes" (N), "Reveal" (Z), "Map" (K). Esc opens the menu.
- Saved games live in this browser on this device. "Export backup …"
  under "Load game" saves them as a file.

NOTES
- Signs, posters and inscriptions drawn into the pictures were left as
  they are.
- Saved games from the German version can be loaded; the game logic is
  unchanged.
